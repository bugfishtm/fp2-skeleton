# Skeleton Module for CMS

This is just a skeleton for developers to quick deploy new modules and see a structure on the default modules directory.  If you want to develope modules using the fast-php-page cms, this is a module skeleton you can start with! It contains all cms related folders and eplanations to make it easier for you to deploy and create modules. 
